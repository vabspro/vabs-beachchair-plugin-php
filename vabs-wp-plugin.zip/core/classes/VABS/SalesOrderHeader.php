<?php

namespace VABS;

class SalesOrderHeader
{
	public int $sellToId = 0;
}
