<?php

namespace VABS;

class Contact
{
	public string $firstname = '';
	public string $lastname  = '';
	public string $email    = '';
	public string $mobile   = '';
	public string $zip_code = '';
	public string $city     = '';
	public string $street = '';
	public string $number = '';

}
